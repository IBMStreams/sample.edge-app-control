#****************************************************************
#Source files which are viewable by a customer when the product is installed
#
#Licensed Materials - Property of IBM
#
#IBM SPSS Products: Analytics Toolkit
#
#© Copyright IBM Corp. 2014
#
#US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP #Schedule Contract with IBM Corp.
#****************************************************************

package SPSSScoring_common;

use strict;
use warnings;
use Cwd 'realpath';
use File::Basename;
use SPL::CodeGen;
use XML::Simple qw(:strict);

## @fn void verifyInputStreams($model)
# This function will do common source checks
# @param model Operator Instance Model
sub verifyInputStreams($) {
	my ($model) = @_;
	my $ninputstreams = $model->getNumberOfInputPorts();

	if($ninputstreams==0) {
		SPL::CodeGen::exitln("No input streams.  At least one input stream must be specified.");
	}
	if($ninputstreams>2) {
		SPL::CodeGen::exitln("Too many input streams.  No more than one input stream can be specified.");
	}
}

## @fn ($infilename, $outfilename, @infields, @infieldtypes, $numinfields, @outfields, @outfieldtypes, $numoutfields) processModelFile($model)
# This function will verify the existence and format
# of the model file parameter, and parse the model
# file to find the infilename, outfilename, infields, infieldtypes, numinfields,
# outfields, outfieldtypes, numoutfields.
# @param model Operator Instance Model
sub processModelFile($)
{
	my ($model) = @_;

	# The following is used to support application bundles
	# If the 'xmlfile' parameter values is a relative path, 
	# the file is assumed to be relative to the 'data' directory
	my $parm_modelfileParam = $model->getParameterByName('xmlfile');
	# this returns the proper text at compile time
	my $parm_modelfile = SPL::CodeGen::compileTimeExpression($model, $parm_modelfileParam->getValueAt(0));
	
	$parm_modelfile =~ s/"(.*?)"/$1/s; # remove the beginning and end quotes
	my $compile_modelpath = File::Spec->canonpath($parm_modelfile);
	
	# check if the path is relative
	if(!File::Spec::Unix->file_name_is_absolute($compile_modelpath)) {
	   if(ref($model->getContext()->getDataDirectory()) eq "HASH") {
	     SPL::CodeGen::exitln("The --data-directory compiler option must be specified when using relative paths.");
	   }
		
	   # convert the relative path to an absolute path, using data directory as the base
	   $compile_modelpath = File::Spec->rel2abs($compile_modelpath, $model->getContext()->getDataDirectory());
	}

	# Check that the model file is readable
	-f $compile_modelpath or SPL::CodeGen::exitln("Model file ". $compile_modelpath. " does not exist or is not a regular file");
	-r $compile_modelpath or SPL::CodeGen::exitln("Model file ". $compile_modelpath. " is not readable");

	# Parse model file to get predictive model information
	my $xs1 = new XML::Simple;
	#my $doc = $xs1->XMLin($compile_modelpath);
	my $doc = XMLin($compile_modelpath, forcearray => [ qw(field) ], keyattr => [] );

	my $infilename;
	$infilename = $doc->{inputDataSources}->{inputDataSource}->{name};

	my $outfilename;
	$outfilename = $doc->{outputDataSources}->{outputDataSource}->{name};


	#//Parse model file to get input fields names
	my @infields;
	my @infieldtypes;
	my $numinfields=0;
	foreach my $field (@{$doc->{inputDataSources}->{inputDataSource}->{fields}->{field}}) {
		$infields[$numinfields] = $field->{name};
		$infieldtypes[$numinfields] = $field->{storage};
		$numinfields++;
	}

	#//Parse model file to get output fields names
	my @outfields;
	my @outfieldtypes;
	my $numoutfields=0;
	foreach my $field (@{$doc->{outputDataSources}->{outputDataSource}->{fields}->{field}}) {
		my $tempstr = $field->{name};
		$tempstr =~ tr/-$ ./_/;
		$outfields[$numoutfields] = $tempstr;
		$outfieldtypes[$numoutfields] = $field->{storage};
		$numoutfields++;
	}

	return (\$infilename, \$outfilename, \@infields, \@infieldtypes, \$numinfields, \@outfields, \@outfieldtypes, \$numoutfields);
}

1;
