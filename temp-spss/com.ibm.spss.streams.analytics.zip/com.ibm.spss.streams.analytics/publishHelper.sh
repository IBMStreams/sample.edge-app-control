#IBM Confidential
#IBM SPSS Products: Analytics Toolkit
#(C) Copyright IBM Corp. 2013
#The source code for this program is not published or otherwise
#divested of its trade secrets, irrespective of what has been
#deposited with the U.S. Copyright Office.

#User Input Area: Start Edit

CDSSERVER=
USERID=
PASSWORD=
TARGETPATH=
EXECPREFIX=java
#EXECPREFIX=java -Xmx256m

#End Edit

STRFILEPATH=$1
TERMINALNODEID=$2

if [ -z "$STRFILEPATH" ]; then
   echo "ERROR: missing Modeler source file reference, nothing to publish."
   echo "    usage: publishHelper.sh <file>"
   exit 1
fi
echo "str File Path:$STRFILEPATH"

if [ -z "$CLEMRUNTIME" ]; then
   echo "ERROR: required CLEMRUNTIME environment variable is not set."
   exit 2
fi

if [ -z "$SPSS_TOOLKIT_INSTALL" ]; then
   echo "ERROR: SPSS_TOOLKIT_INSTALL required environment variable is not set"
   echo "to indicate parent directory of the SPSS Analytics Toolkit install."
   exit 3
fi

if [ -n "$CDSSERVER" ]; then
	echo "C&DS Server: $CDSSERVER"
else
	CDSSERVER=ignore
	echo "This publishing process will work without connecting to a C&DS server."
fi

if [ -n "$USERID" ]; then
	echo "User ID has been set."
else
	USERID=ignore
fi

if [ -n "$PASSWORD" ]; then
	echo "Password has been set."
else
	PASSWORD=ignore
fi

if [ -n "$TARGETPATH" ]; then
	echo "Target path: $TARGETPATH"
else	
	len=${#STRFILEPATH}-4
	STRFILEFOLDER=${STRFILEPATH:0:$len}
	TARGETPATH=$STRFILEFOLDER
	echo "The Modeler source file directory will be used as the target:"
	echo "        $TARGETPATH"
fi

if [ -n "$TERMINALNODEID" ]; then
	echo "Terminal Node ID in str:$TERMINALNODEID"
else
	TERMINALNODEID=ignore
	echo "Terminal node ID as defined in the file's deploy information will be used for publishing."
fi

TOOLKITJARPATH=$SPSS_TOOLKIT_INSTALL/impl/lib/SPSSAnalytics.jar
CLASSPATH=./:$CLEMRUNTIME/lib/*:$TOOLKITJARPATH
export CLASSPATH

$EXECPREFIX com.ibm.spss.streams.analytics.publish.Publisher $CLEMRUNTIME $CDSSERVER $USERID $PASSWORD $STRFILEPATH $TARGETPATH $TERMINALNODEID
