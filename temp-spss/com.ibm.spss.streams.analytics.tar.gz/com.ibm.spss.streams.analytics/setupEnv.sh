#IBM Confidential
#IBM SPSS Products: Analytics Toolkit
#(C) Copyright IBM Corp. 2014
#The source code for this program is not published or otherwise
#divested of its trade secrets, irrespective of what has been
#deposited with the U.S. Copyright Office.

#IMPORTANT: Setting the CLEMRUNTIME environment is required.
#Define path and remove comment if specified via this script
#export CLEMRUNTIME=???

#NOTE: Definition of the SPSS_TOOLKIT_INSTALL variable is suggested, here or by other means.
#Define path and remove comment if specified via this script
#export SPSS_TOOLKIT_INSTALL=???

#NOTE: Add SPSS_TOOLKIT_INSTALL to the STREAMS_SPLPATH if this toolkit is not
# installed under the common InfoSphere Streams 'toolkits' root directory.
#Remove comment if STREAMS_SPLPATH modified by this script.
#export STREAMS_SPLPATH=$STREAMS_SPLPATH:SPSS_TOOLKIT_INSTALL

if [ -z "$CLEMRUNTIME" ]; then
   echo "ERROR: missing required CLEMRUNTIME environment variable."
   exit 1
fi

DLLIBPATH=$CLEMRUNTIME
CLEFEXTBIN=$CLEMRUNTIME/ext/bin
for CLEFEXTNAME in $CLEFEXTBIN/*
do
		DLLIBPATH=$DLLIBPATH:$CLEFEXTNAME
        if [ -f $CLEFEXTNAME/envsetting.sh ]; then
           cd $CLEFEXTNAME
           . $CLEFEXTNAME/envsetting.sh
		   cd $CLEMRUNTIME
        fi
done

#NOTE: if using SPSS Analytical Decision Management
# append the JRE bin directories to the library search path
# to enable load of the JVM dynamically for ADM rules nodes
JREBINPATH=$CLEMRUNTIME/jre/bin
if [ -d $JREBINPATH ]; then
   if [ -d $JREBINPATH/classic ]; then
      DLLIBPATH=$DLLIBPATH:$JREBINPATH/classic
   fi
   DLLIBPATH=$DLLIBPATH:$JREBINPATH
fi

# first set the LD_LIBRARY_PATH to find libraries in the
# SPSS Modeler Solution Publisher installation directory
if [ -z "${LD_LIBRARY_PATH}" ]; then
    LD_LIBRARY_PATH=$DLLIBPATH
else
    LD_LIBRARY_PATH=$DLLIBPATH:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH

# Do not set LD_LIBRARY_PATH_64 unless already set
if [ -n "${LD_LIBRARY_PATH_64}" ]; then
    LD_LIBRARY_PATH_64=$DLLIBPATH:$LD_LIBRARY_PATH_64
    export LD_LIBRARY_PATH_64
fi
