#IBM Confidential
#IBM SPSS Products: Analytics Toolkit
#(C) Copyright IBM Corp. 2012
#The source code for this program is not published or otherwise
#divested of its trade secrets, irrespective of what has been
#deposited with the U.S. Copyright Office.
CLEMRUNTIME=/p3/Official

CLASSPATH=./
CLASSPATH=$CLASSPATH
PSAPILIBPATH=$CLEMRUNTIME/lib
for JARNAME in $PSAPILIBPATH/*.jar
do
        CLASSPATH=$CLASSPATH:$JARNAME
done

ANALYTICSJARPATH=$STREAMS_TOOLKIT_INSTALL/impl/lib/SPSSAnalytics.jar
CLASSPATH=$CLASSPATH:$ANALYTICSJARPATH

java -classpath $CLASSPATH com.ibm.spss.streams.analytics.utility.PasswordEncoder
